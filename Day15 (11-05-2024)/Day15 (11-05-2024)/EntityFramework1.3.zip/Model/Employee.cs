﻿namespace Entity.Model
{
    public class Employee
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string place { get; set; }

    }
}
