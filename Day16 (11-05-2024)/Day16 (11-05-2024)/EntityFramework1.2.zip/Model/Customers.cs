﻿namespace EntityFramework.Model
{
    public class Customers
    {
        public int Id { get; set; }
        public string CustomerName { get; set; }
    }
}
