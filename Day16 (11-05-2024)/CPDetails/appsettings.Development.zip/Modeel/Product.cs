﻿namespace CPDetails.Modeel
{
    public class Product
    {
        public int Id { get; set; }
        public required string ProductName { get; set; }
    }
}
