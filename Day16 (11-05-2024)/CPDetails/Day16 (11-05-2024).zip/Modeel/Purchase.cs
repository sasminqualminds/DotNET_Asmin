﻿namespace CPDetails.Modeel
{
    public class Purchase
    {
        public int Id { get; set; }
        public int CustomerId { get; set; }

        public int ProductId { get; set; }
    }
}
