﻿namespace Employee
{
    // enum
    public enum MenuOption
    {
        Add = 1,
        Delete = 2,
        Update = 3,
        List = 4,
        ListAllEmployees=5,
        Exit = 6,
    }
}