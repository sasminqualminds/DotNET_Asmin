﻿using System.Collections;

namespace Employee
{
    public class Program
    {
       
        static void Main(string[] args)
        { 
            
            Employee employee=new Employee();
            EmployeeOperations operations=new EmployeeOperations();
            operations.defaultValues();

            bool exit = false;
             
            while (!exit)
            {
                MenuOption userinput = ReadUserOption.ReadUserInputOption();

                switch (userinput)
                {
                    case MenuOption.Add:
                      operations.add(employee);                      
                        break;
                    case MenuOption.Delete:
                        Console.WriteLine();
                        operations.delete(employee);

                        break;
                    case MenuOption.Update:
                        operations.update(employee);
                        Console.WriteLine();

                        break;
                    case MenuOption.List:
                        operations.listEmployee(employee);

                        break;
                    case MenuOption.ListAllEmployees:
                        operations.listAllEmployee(employee);

                        break;
                    case MenuOption.Exit:
                        exit = true;
                        break;
                    default:
                        Console.WriteLine("Invalid option. Please try again.");
                        break;
                }
            }
           
            

            
            
        }
    }
}
