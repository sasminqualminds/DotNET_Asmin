﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Employee
{
    
    internal class EmployeeOperations
    {
        // creating an array list
        private ArrayList empList = new ArrayList();
       
        // adding default values to array list
        public void defaultValues()
        {
            empList.Add(new Employee { EmpName = "Robbin", EmpId = 1, EmpAddress = "Chennai", EmpSalary = 300000 });
            empList.Add(new Employee { EmpName = "Jack", EmpId = 2, EmpAddress = "Hyderabad", EmpSalary = 300000 });

        }
    
        
        /*  ------------------- adding an employee  -----------------------*/
        public void add(Employee employee)
        {
            Console.WriteLine("enter name");
            employee.EmpName = Console.ReadLine();
            Console.WriteLine("enter Id");
            employee.EmpId = Convert.ToInt16(Console.ReadLine());
            
            foreach (Employee emp in empList)
            {
                if (emp.EmpId == employee.EmpId)
                {
                    Console.WriteLine("Id already exists");
                    Console.WriteLine("Enter another id");
                    employee.EmpId = Convert.ToInt16(Console.ReadLine());
                }
            }
            Console.WriteLine("enter address");
            employee.EmpAddress = Console.ReadLine();
            Console.WriteLine("enter Salary");
            employee.EmpSalary = Convert.ToDecimal(Console.ReadLine());
            empList.Add(employee);
            Console.WriteLine();
           Console.WriteLine("Employee name:{0}\nEmployee id:{1}\nEmployee address:{2}\nEmployee salary:{3}",employee.EmpName,employee.EmpId,employee.EmpAddress,employee.EmpSalary);
            Console.WriteLine();
        }

        /*  -------------------- removing an employee based on employee id  ---------------------*/
        public void delete(Employee employee)
        {
            Console.WriteLine("List of all employees");
            foreach (Employee emp in empList)
            {               
            Console.WriteLine("Employee \nname:{0}\nId:{3}\nAddress:{2}\nSalary:{1}", emp.EmpName, emp.EmpSalary, emp.EmpAddress, emp.EmpId); 
            Console.WriteLine();
            }
            Console.WriteLine("enter employee id to delete");
            int id = Convert.ToInt16(Console.ReadLine());
            ArrayList a2= new ArrayList(empList);
            
            foreach (Employee emp in a2)
            {
                if (emp.EmpId.Equals(id))
                {
                    empList.Remove(emp);
                }
                
            }
            
            Console.WriteLine("List of employees after deleting");
            foreach (Employee emp in empList)
            {
                Console.WriteLine("Employee \nname:{0}\nId:{3}\nAddress:{2}\nSalary:{1}", emp.EmpName, emp.EmpSalary, emp.EmpAddress, emp.EmpId);
                Console.WriteLine();
            }
            Console.WriteLine();
        }

        /*  --------------- Employee details based on id  ------------------*/

        public void listEmployee(Employee employee)
        {
            Console.WriteLine("enter employee id:");
            int id=Convert.ToInt16(Console.ReadLine());
            foreach (Employee emp in empList)
            {
               
                if (emp.EmpId.Equals(id))
                {
                    Console.WriteLine("Employee {4} \nname:{0}\nId:{3}\nAddress:{2}\nSalary:{1}", emp.EmpName, emp.EmpSalary, emp.EmpAddress, emp.EmpId,i);
                    
                }
                else
                {
                    Console.WriteLine("no employee found");
                }
            }
            Console.WriteLine();
        }

        /*--------------  listing all employee deatils  ------------------*/

        int i = 1;
        public void listAllEmployee(Employee employee)
        {
           
            Console.WriteLine("List of all employees");
            Console.WriteLine();
            foreach (Employee emp in empList)
            {
                
                Console.WriteLine("Employee {4}\nname:{0}\nId:{3}\nAddress:{2}\nSalary:{1}", emp.EmpName, emp.EmpSalary, emp.EmpAddress, emp.EmpId,i);
                i = i + 1;
                
                Console.WriteLine();
            }
            i = 1;
            Console.WriteLine();
        }

        /*------------- Updating Employee Details based on Id from user  ------------------*/
        public void update(Employee employee)
        {
            
            Employee employeeToUpdate = null;
            Console.WriteLine("Enter id");
            int id= Convert.ToInt16(Console.ReadLine());
            foreach (Employee emp in empList)
            {
                if (emp.EmpId == id)
                {
                    employeeToUpdate = emp;
                    break;
                }
            }

            if (employeeToUpdate != null)
            {
               
                Console.WriteLine("Enter the updated details of the employee with ID " + id + ":");
                Console.Write("Name: ");
                employee.EmpName = Console.ReadLine();

                Console.Write("Address: ");
                employee.EmpAddress= Console.ReadLine();

                Console.Write("Salary: ");
                double salary;
                employee.EmpSalary = Convert.ToDecimal(Console.ReadLine());
                employeeToUpdate.EmpName = employee.EmpName;
                employeeToUpdate.EmpAddress = employee.EmpAddress;
                employeeToUpdate.EmpSalary = employee.EmpSalary;

                Console.WriteLine("Employee details updated successfully!");
            }
            else
            {
                Console.WriteLine("Employee with ID " + id + " not found.");
            }
        }
    }
    
}
