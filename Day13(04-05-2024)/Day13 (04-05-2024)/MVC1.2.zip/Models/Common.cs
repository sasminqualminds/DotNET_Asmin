﻿using MVC1._2.Controllers;

namespace MVC1._2.Models
{
    public class Common
    {
        public List<Employee> Employees { get; set; }
        public List<Course> Courses { get; set; }  
        

    }
}
