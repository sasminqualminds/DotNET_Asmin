﻿namespace MVC1._2.Models
{
    public class Employee
    {
        public int EmployeeId { get; set; } 
        public string EmployeeName { get; set; }
        public int EmployeeAge { get; set; }
        public decimal EmployeeSalary {  get; set; }
    }
}
